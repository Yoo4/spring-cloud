package com.blueskykong.demo.constants;

/**
 * Created by keets on 2017/12/9.
 */
public class SecurityConstants {
    public static final String USER_ID_IN_HEADER = "X-AOHO-UserId";
    public static final String AUTH_SERVICE = "auth";

}
