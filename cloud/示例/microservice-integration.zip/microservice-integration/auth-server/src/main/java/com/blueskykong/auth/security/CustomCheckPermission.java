package com.blueskykong.auth.security;/*
package com.blueskykong.auth.security;

import org.springframework.security.oauth2.provider.CheckPermissions;
import org.springframework.security.oauth2.provider.entity.CheckTokenEntity;
import org.springframework.stereotype.Component;


*/
/**
 *
 * @author keets
 * @date 2017/9/25
 *//*

@Component
public class CustomCheckPermission implements CheckPermissions {


    @Override
    public boolean checkPermission(CheckTokenEntity checkTokenEntity) {
        return false;
    }
}
*/
