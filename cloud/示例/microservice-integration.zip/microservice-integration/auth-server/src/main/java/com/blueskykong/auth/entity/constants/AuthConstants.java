package com.blueskykong.auth.entity.constants;

/**
 * Created by keets on 2017/1/17.
 */
public class AuthConstants {
    public static String AUTH_REDIS_DEVICE = "auth_deviceId_";
}
