package com.blueskykong.auth.entity;

/**
 * Created by keets on 2016/12/5.
 */
public enum ClientSecretStatus {
    ACTIVE, INACTIVE
}
