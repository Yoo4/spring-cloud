#!/usr/bin/env bash
mvn clean scala:compile scala:run -Dlauncher=app
