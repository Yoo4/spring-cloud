Python服务端示例：
https://gitee.com/superjery/tornado_boilerplate

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
需以下根文件：
 __init__.py  
 application.py  
 server.py  
 urls.py
 
需以下根文件夹：
 handlers
 model
 static
 templates
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Python 安装 3.5
tornado 安装 4.5
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

运行python server.py即可启动Web

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

两种访问接口方式:
http://localhost:5689/ace-sidecar-client-demo/test/test
http://localhost:5689/ace-sidecar-client-demo/message/123
