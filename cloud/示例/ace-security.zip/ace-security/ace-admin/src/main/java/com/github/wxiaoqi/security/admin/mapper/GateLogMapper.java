package com.github.wxiaoqi.security.admin.mapper;

import com.github.wxiaoqi.security.admin.entity.GateLog;
import tk.mybatis.mapper.common.Mapper;

public interface GateLogMapper extends Mapper<GateLog> {
}