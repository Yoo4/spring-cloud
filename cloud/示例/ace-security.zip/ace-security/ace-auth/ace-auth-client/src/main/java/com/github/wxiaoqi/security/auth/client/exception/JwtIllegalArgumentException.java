package com.github.wxiaoqi.security.auth.client.exception;

/**
 * Created by ace on 2017/9/15.
 */
public class JwtIllegalArgumentException extends Exception {
    public JwtIllegalArgumentException(String s) {
        super(s);
    }
}
