package com.huaxin.springcloudservicezuul.controller;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@Component
public class AccessFilter extends ZuulFilter{
    private static Logger log = LoggerFactory.getLogger(AccessFilter.class);
    @Override
    public String filterType() {
        //前置过滤器
        return "pre";
    }

    @Override
    public int filterOrder() {
        //优先级，数字越大，优先级越低
        return 0;
    }

    @Override
    public boolean shouldFilter() {
        //是否启用多滤器
        return false;
    }

    @Override
    public Object run() {

        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();
        String token=request.getHeader("access-token");
        log.info("send {} request to {}",request.getMethod(),request.getRequestURL().toString());
        log.info(request.getRequestURI().substring("/api".length()));
        if (request.getRequestURI().substring("/auth".length()).startsWith("/oauth/token"))
            return null;
        Object accessToken = request.getHeader("Authorization");
        if (accessToken==null){
            log.warn("Authorization token is empty");
            ctx.setSendZuulResponse(false);
            ctx.setResponseStatusCode(401);
            ctx.setResponseBody("Authorization token is empty");
           // return null;
        }
        log.info("Authorization token is ok");
        return null;
    }
}
