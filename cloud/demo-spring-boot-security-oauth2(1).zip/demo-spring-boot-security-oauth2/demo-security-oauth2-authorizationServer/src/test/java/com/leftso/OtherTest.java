package com.leftso;

import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public class OtherTest {
	public static void main(String[] args) {
		try {
//			String access_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsic3ByaW5nLWJvb3QtYXBwbGljYXRpb24iXSwidXNlcl9uYW1lIjoibGVmdHNvIiwic2NvcGUiOlsicmVhZCJdLCJyb2xlcyI6W3siYXV0aG9yaXR5IjoiUk9MRV9VU0VSIn1dLCJleHAiOjE1MTQxODQyMzIsInVzZXJOYW1lIjoibGVmdHNvIiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6IjA2ZjcyYTk4LWM4OTAtNDY2OS05NDY4LWU1MjQyNTM2NDcyYSIsImNsaWVudF9pZCI6Im5vcm1hbC1hcHAifQ.LXDX8h9GpF96wx2X-8C06Lml7NjI2ooGB2AcqCKHufg";
//			String access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsic3ByaW5nLWJvb3QtYXBwbGljYXRpb24iXSwidXNlcl9uYW1lIjoibGVmdHNvIiwic2NvcGUiOlsicmVhZCJdLCJyb2xlcyI6W3siYXV0aG9yaXR5IjoiUk9MRV9VU0VSIn1dLCJleHAiOjE1MTQxODQyMzIsInVzZXJOYW1lIjoibGVmdHNvIiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6IjA2ZjcyYTk4LWM4OTAtNDY2OS05NDY4LWU1MjQyNTM2NDcyYSIsImNsaWVudF9pZCI6Im5vcm1hbC1hcHAifQ.LXDX8h9GpF96wx2X-8C06Lml7NjI2ooGB2AcqCKHufg";
			String access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsic3ByaW5nLWJvb3QtYXBwbGljYXRpb24iXSwidXNlcl9uYW1lIjoibGVmdHNvIiwic2NvcGUiOlsicmVhZCJdLCJyb2xlcyI6W3siYXV0aG9yaXR5IjoiUk9MRV9VU0VSIn1dLCJleHAiOjE1MTQxOTgxMzQsInVzZXJOYW1lIjoibGVmdHNvIiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6IjUzMWEwMTViLWVhYjMtNDBiNS1iN2RhLWFjZWU4ODgwYWRjNyIsImNsaWVudF9pZCI6Im5vcm1hbC1hcHAifQ.t8DM1OiojjMKqGKnqqIavzH6UNiU3hzWTFpfGJJrd4I";
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Bearer " + access_token);
			ResponseEntity<String> response = new TestRestTemplate().exchange("http://localhost:" + 8080 + "/resources/roles", HttpMethod.GET,
					new HttpEntity<>(null, headers), String.class);
			System.out.println(response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
